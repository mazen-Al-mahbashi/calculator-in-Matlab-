function varargout = untitled(varargin)
% UNTITLED MATLAB code for untitled.fig
%      UNTITLED, by itself, creates a new UNTITLED or raises the existing
%      singleton*.
%
%      H = UNTITLED returns the handle to a new UNTITLED or the handle to
%      the existing singleton*.
%
%      UNTITLED('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in UNTITLED.M with the given input arguments.
%
%      UNTITLED('Property','Value',...) creates a new UNTITLED or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before untitled_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to untitled_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE'ss Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help untitled

% Last Modified by GUIDE v2.5 27-Oct-2022 13:55:08

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @untitled_OpeningFcn, ...
                   'gui_OutputFcn',  @untitled_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
   gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before untitled is made visible.
function untitled_OpeningFcn(hObject, ~, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to untitled (see VARARGIN)

% Choose default command line output for untitled
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes untitled wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = untitled_OutputFcn(hObject, ~, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
anser=get(handles.anst,'string');
% --- Executes on button press in ting.
function ting_Callback(hObject, eventdata, handles)
% hObject    handle to ting (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.tingp,'visible','on')
set(handles.tingo,'visible','on')
set(handles.hypp,'visible','off')
set(handles.hypo,'visible','off')
% --- Executes on button press in log.
function log_Callback(hObject, eventdata, handles)
% hObject    handle to log (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

right=get(handles.frm,'string');
right=strcat(right,'log(');
set(handles.frm,'string',right)
% --- Executes on button press in log10.
function log10_Callback(hObject, eventdata, handles)
% hObject    handle to log10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
right=get(handles.frm,'string');
right=strcat(right,'log10(');
set(handles.frm,'string',right)

% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes on button press in sin.
function sin_Callback(hObject, eventdata, handles)
% hObject    handle to sin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
lift=get(handles.frm,'string');
lift=strcat(lift,'sin(');
set(handles.frm,'string',lift)

% --- Executes on button press in cos.
function cos_Callback(hObject, eventdata, handles)
% hObject    handle to cos (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
lift=get(handles.frm,'string');
lift=strcat(lift,'cos(');
set(handles.frm,'string',lift)

% --- Executes on button press in xv.
function xv_Callback(hObject, eventdata, handles)
% hObject    handle to xv (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
lift=get(handles.frm,'string');
lift=strcat(lift,'x');
set(handles.frm,'string',lift)


% --- Executes on button press in yv.
function yv_Callback(hObject, eventdata, handles)
% hObject    handle to yv (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
lift=get(handles.frm,'string');
lift=strcat(lift,'y');
set(handles.frm,'string',lift)


% --- Executes on button press in lift.
function lift_Callback(hObject, eventdata, handles)
% hObject    handle to lift (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
lift=get(handles.frm,'string');
lift=strcat(lift,'(');
set(handles.frm,'string',lift)

% --- Executes on button press in right.
function right_Callback(hObject, eventdata, handles)
% hObject    handle to right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
right=get(handles.frm,'string');
right=strcat(right,')');
set(handles.frm,'string',right)

% --- Executes on button press in pi.
function pi_Callback(hObject, eventdata, handles)
% hObject    handle to pi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
right=get(handles.frm,'string');
right=strcat(right,'pi');
set(handles.frm,'string',right)

% --- Executes on button press in power.
function power_Callback(hObject, eventdata, handles)
% hObject    handle to power (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
n1=get(handles.frm,'string');
n1=strcat(n1,'^');
set(handles.frm,'string',n1)

% --- Executes on button press in sq2.
function sq2_Callback(hObject, eventdata, handles)
% hObject    handle to sq2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
n1=get(handles.frm,'string');
n1=strcat(n1,'sqrt(');
set(handles.frm,'string',n1)

% --- Executes on button press in n8.
function n8_Callback(hObject, eventdata, handles)
% hObject    handle to n8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
n8=get(handles.frm,'string');
n8=strcat(n8,'8');
set(handles.frm,'string',n8)

% --- Executes on button press in n9.
function n9_Callback(hObject, eventdata, handles)
% hObject    handle to n9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
n9=get(handles.frm,'string');
n9=strcat(n9,'9');
set(handles.frm,'string',n9)

% --- Executes on button press in div.
function div_Callback(hObject, eventdata, handles)
% hObject    handle to div (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
div=get(handles.frm,'string');
div=strcat(div,'/');
set(handles.frm,'string',div)

% --- Executes on button press in n6.
function n6_Callback(hObject, eventdata, handles)
% hObject    handle to n6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
n6=get(handles.frm,'string');
n6=strcat(n6,'6');
set(handles.frm,'string',n6)

% --- Executes on button press in x.
function x_Callback(hObject, eventdata, handles)
% hObject    handle to x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
x=get(handles.frm,'string');
x=strcat(x,'*');
set(handles.frm,'string',x)

% --- Executes on button press in n4.
function n4_Callback(hObject, eventdata, handles)
% hObject    handle to n4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
n4=get(handles.frm,'string');
n4=strcat(n4,'4');
set(handles.frm,'string',n4)

% --- Executes on button press in n5.
function n5_Callback(hObject, eventdata, handles)
% hObject    handle to n5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

n5=get(handles.frm,'string');
n5=strcat(n5,'5');
set(handles.frm,'string',n5)
% --- Executes on button press in cle.
function cle_Callback(hObject, eventdata, handles)
% hObject    handle to cle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.frm,'string','')
set(handles.res,'string','')
set(handles.diff2,'visible','off')
set(handles.dgr,'visible','off')
set(handles.intg2,'visible','off')

% --- Executes on button press in n7.
function n7_Callback(hObject, eventdata, handles)
% hObject    handle to n7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
n7=get(handles.frm,'string');
n7=strcat(n7,'7');
set(handles.frm,'string',n7)

% --- Executes on button press in mins.
function mins_Callback(hObject, eventdata, handles)
% hObject    handle to mins (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

mins=get(handles.frm,'string');
mins=strcat(mins,'-');
set(handles.frm,'string',mins)
% --- Executes on button press in hyp.
function hyp_Callback(hObject, eventdata, handles)
% hObject    handle to hyp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.hypp,'visible','on')
set(handles.hypo,'visible','on')
% --- Executes on button press in dffn.
function dffn_Callback(hObject, eventdata, handles)
% hObject    handle to dffn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
a=get(handles.frm,'string');
x=str2sym(a);
y=diff(x);
z=string(y);
set(handles.res,'string',z)
set(handles.diff2,'visible','on')
set(handles.dgr,'visible','on')
set(handles.dgr,'string',1)

% --- Executes on button press in bt.
function bt_Callback(hObject, eventdata, handles)
% hObject    handle to bt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
a=get(handles.res,'string');
set(handles.frm,'string',a)



% --- Executes on button press in intg.
function intg_Callback(hObject, eventdata, handles)
% hObject    handle to intg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

a=get(handles.frm,'string');
x=str2sym(a);
y=int(x);
z=string(y);
set(handles.res,'string',z)
set(handles.intg2,'visible','on')
set(handles.dgr,'visible','on')
set(handles.dgr,'string',1)

% --- Executes on button press in e.
function e_Callback(hObject, eventdata, handles)
% hObject    handle to e (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

right=get(handles.frm,'string');
right=strcat(right,'exp(');
set(handles.frm,'string',right)
% --- Executes on button press in eql.
function eql_Callback(hObject, eventdata, handles)
% hObject    handle to eql (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

lift=get(handles.frm,'string');
lift=strcat(lift,'=');
set(handles.frm,'string',lift)

% --- Executes on button press in zero.
function zero_Callback(hObject, eventdata, handles)
% hObject    handle to zero (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
zero=get(handles.frm,'string');
zero=strcat(zero,'0');
set(handles.frm,'string',zero)

% --- Executes on button press in n.
function n_Callback(hObject, eventdata, handles)
% hObject    handle to n (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
n=get(handles.frm,'string');
n=strcat(n,'.');
set(handles.frm,'string',n)

% --- Executes on button press in sn.
function sn_Callback(hObject, eventdata, handles)
% hObject    handle to sn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
n1=get(handles.frm,'string');
n1=str2double(n1);
n=-n1;
set(handles.frm,'string',num2str(n));

% --- Executes on button press in plus.
function plus_Callback(hObject, eventdata, handles)
% hObject    handle to plus (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
plus=get(handles.frm,'string');
plus=strcat(plus,'+');
set(handles.frm,'string',plus)

% --- Executes on button press in n1.
function n1_Callback(hObject, eventdata, handles)
% hObject    handle to n1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
n1=get(handles.frm,'string');
n1=strcat(n1,'1');
set(handles.frm,'string',n1)
% --- Executes on button press in n2.
function n2_Callback(hObject, eventdata, handles)
% hObject    handle to n2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
n2=get(handles.frm,'string');
n2=strcat(n2,'2');
set(handles.frm,'string',n2)

% --- Executes on button press in n3.
function n3_Callback(hObject, eventdata, handles)
% hObject    handle to n3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

n3=get(handles.frm,'string');
n3=strcat(n3,'3');
set(handles.frm,'string',n3)
% --- Executes on button press in ans.
function ans_Callback(hObject, eventdata, handles)
% hObject    handle to ans (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

n1=get(handles.anst,'string');
n=str2num(n1)
set(handles.frm,'string',n);

% --- Executes on button press in del.
function del_Callback(hObject, eventdata, handles)
% hObject    handle to del (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
n=get(handles.frm,'string')
n=n(1:end-1)
set(handles.frm,'string',n)
% --- Executes on button press in eq.
function eq_Callback(hObject, eventdata, handles)
% hObject    handle to eq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
n1=get(handles.frm,'string');
n=eval(n1)
set(handles.res,'string',num2str(n));
ansr=get(handles.res,'string')
set(handles.anst,'string',ansr)

% --- Executes on button press in tingo.
function tingo_Callback(hObject, eventdata, handles)
% hObject    handle to tingo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.tingp,'visible','off')
set(handles.tingo,'visible','off')


% --- Executes on button press in tan.
function tan_Callback(hObject, eventdata, handles)
% hObject    handle to tan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

right=get(handles.frm,'string');
right=strcat(right,'tan(');
set(handles.frm,'string',right)
% --- Executes on button press in sec.
function sec_Callback(hObject, eventdata, handles)
% hObject    handle to sec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
lift=get(handles.frm,'string');
lift=strcat(lift,'sec(');
set(handles.frm,'string',lift)

% --- Executes on button press in csc.
function csc_Callback(hObject, eventdata, handles)
% hObject    handle to csc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
csc=get(handles.frm,'string');
csc=strcat(csc,'csc(');
set(handles.frm,'string',csc)

% --- Executes on button press in cos1.
function cos1_Callback(hObject, eventdata, handles)
% hObject    handle to cos1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
lift=get(handles.frm,'string');
lift=strcat(lift,'acos(');
set(handles.frm,'string',lift)

% --- Executes on button press in tan1.
function tan1_Callback(hObject, eventdata, handles)
% hObject    handle to tan1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
right=get(handles.frm,'string');
right=strcat(right,'atan(');
set(handles.frm,'string',right)
% --- Executes on button press in sec1.
function sec1_Callback(hObject, eventdata, handles)
% hObject    handle to sec1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
asec=get(handles.frm,'string');
asec=strcat(asec,'asec(');
set(handles.frm,'string',asec)
% --- Executes on button press in csc1.
function csc1_Callback(hObject, eventdata, handles)
% hObject    handle to csc1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sin=get(handles.frm,'string');
sin=strcat(sin,'acsc(');
set(handles.frm,'string',sin)

% --- Executes on button press in sin1.
function sin1_Callback(hObject, eventdata, handles)
% hObject    handle to sin1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sin=get(handles.frm,'string');
sin=strcat(sin,'asin(');
set(handles.frm,'string',sin)
% --- Executes on button press in sinh.
function sinh_Callback(hObject, eventdata, handles)
% hObject    handle to sinh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sin=get(handles.frm,'string');
sin=strcat(sin,'sinh(');
set(handles.frm,'string',sin)

% --- Executes on button press in cosh.
function cosh_Callback(hObject, eventdata, handles)
% hObject    handle to cosh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sin=get(handles.frm,'string');
sin=strcat(sin,'cosh(');
set(handles.frm,'string',sin)

% --- Executes on button press in hypo.
function hypo_Callback(hObject, eventdata, handles)
% hObject    handle to hypo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.hypp,'visible','off')
set(handles.hypo,'visible','off')


% --- Executes on button press in abs.
function abs_Callback(hObject, eventdata, handles)
right=get(handles.frm,'string');
right=strcat(right,'abs(');
set(handles.frm,'string',right)
% hObject    handle to abs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in x1.
function x1_Callback(hObject, eventdata, handles)
% hObject    handle to x1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

right=str2num(get(handles.frm,'string'));
right=1/right;
num2str(set(handles.frm,'string',right))

% --- Executes on button press in i.
function i_Callback(hObject, eventdata, handles)
% hObject    handle to i (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
right=get(handles.frm,'string');
right=strcat(right,'i');
set(handles.frm,'string',right)




% --- Executes on button press in diff2.
function diff2_Callback(hObject, eventdata, handles)
% hObject    handle to diff2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
a=get(handles.res,'string');
x=str2sym(a);
y=diff(x);
z=string(y);
if str2num(a)==0
    set(handles.diff2,'visible','off')
end
set(handles.res,'string',z)
right=str2num(get(handles.dgr,'string'));

right=1+right;
num2str(set(handles.dgr,'string',right))


% --- Executes during object creation, after setting all properties.
function dgr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dgr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
    
    


% --- Executes on button press in intg2.
function intg2_Callback(hObject, eventdata, handles)
% hObject    handle to intg2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
a=get(handles.res,'string');
x=str2sym(a);
y=int(x);
z=string(y);
if str2num(a)==0
    set(handles.intg2,'visible','off')
end
set(handles.res,'string',z)
right=str2num(get(handles.dgr,'string'));

right=1+right;
num2str(set(handles.dgr,'string',right))


% --- Executes on button press in d2.
function d2_Callback(hObject, eventdata, handles)
% hObject    handle to d2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

wave
% --- Executes on button press in ode.
function ode_Callback(hObject, eventdata, handles)
% hObject    handle to ode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ODE

% --- Executes on button press in ns.
function ns_Callback(hObject, eventdata, handles)
% hObject    handle to ns (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.nsp,'visible','on')
% --- Executes on selection change in inp.
function inp_Callback(hObject, eventdata, handles)
% hObject    handle to inp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints:  returns inp contents as cell array
%        contents{get(hObject,'Value')} returns selected item from inp
global s
s=get(handles.inp,'value');

% --- Executes on button press in tanh.
function tanh_Callback(hObject, eventdata, handles)
% hObject    handle to tanh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sin=get(handles.frm,'string');
sin=strcat(sin,'tanh(');
set(handles.frm,'string',sin)


% --- Executes on selection change in ss.
function ss_Callback(hObject, eventdata, handles)
% hObject    handle to ss (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns ss contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ss

% Hints:  returns inp contents as cell array
%        contents{get(hObject,'Value')} returns selected item from inp
global d s
d=get(handles.ss,'value')
switch s
    case 1
        switch d
            case 1
        x=get(handles.mo,'string')
        x=base2dec(x,10)
        set(handles.out2,'string',x)
       
            case 2
         x=get(handles.mo,'string')
        x=base2dec(x,10)
        x=dec2base(x,2)
        set(handles.out2,'string',x)
        
            case 3
        x=get(handles.mo,'string')
        x=base2dec(x,10)
        x=dec2base(x,8)
        set(handles.out2,'string',x)
        
            case 4
        x=get(handles.mo,'string')
         x=base2dec(x,10)
        x=dec2base(x,16)
        set(handles.out2,'string',x)
        
        end
    case 2
         switch d
            case 1
        x=get(handles.mo,'string')
        x=base2dec(x,2)
        x=dec2base(x,10)
        set(handles.out2,'string',x)
        
            case 2
        x=get(handles.mo,'string')
        x=base2dec(x,2)
        x=dec2base(x,2)
        set(handles.out2,'string',x)
        
            case 3
        x=get(handles.mo,'string')
       x=base2dec(x,2)
        x=dec2base(x,8)
        set(handles.out2,'string',x)
        
            case 4
        x=get(handles.mo,'string')
        x=base2dec(x,2)
        x=dec2base(x,16)
        set(handles.out2,'string',x)
         
         end
    case 3
               switch d
            case 1
        x=get(handles.mo,'string')
      x=base2dec(x,8)
        x=dec2base(x,10)
        set(handles.out2,'string',x)
        
            case 2
        x=get(handles.mo,'string')
        x=base2dec(x,8)
        x=dec2base(x,2)
        set(handles.out2,'string',x)
       
            case 3
        x=get(handles.mo,'string')
        x=base2dec(x,8)
        x=dec2base(x,8)
        set(handles.out2,'string',x)
         
            case 4
        x=get(handles.mo,'string')
       x=base2dec(x,8)
        x=dec2base(x,16)
        set(handles.out2,'string',x)
        
               end
    case  4
        switch d
            case 1
        x=get(handles.mo,'string')
        x=base2dec(x,16)
        x=dec2base(x,10)
        set(handles.out2,'string',x)
         
            case 2
        x=get(handles.mo,'string')
        x=base2dec(x,16)
        x=dec2base(x,2)
        set(handles.out2,'string',x)
         
            case 3
        x=get(handles.mo,'string')
        x=base2dec(x,16)
        x=dec2base(x,8)
        set(handles.out2,'string',x)
        
            case 4
        x=get(handles.mo,'string')
        x=base2dec(x,16)
        x=dec2base(x,16)
        set(handles.out2,'string',x)
         
         end
        
end




function in2_Callback(hObject, eventdata, handles)
% hObject    handle to ss (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ss as text
%        str2double(get(hObject,'String')) returns contents of ss as a double


% --- Executes during object creation, after setting all properties.
function in2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ss (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function out2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to out2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function ss_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ss (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function inp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to inp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function Untitled_1_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_2_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_6_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_3_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_4_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_5_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
